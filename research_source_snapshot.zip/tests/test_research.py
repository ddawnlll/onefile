"""H1-A and symmetric execution: synthetic/offline tests, never open holdouts."""
import argparse
import json
import unittest
from pathlib import Path
from unittest.mock import patch

import numpy as np
import pandas as pd
from pandas.testing import assert_frame_equal
from test_one import TemporaryFiles, market_frame

import one


class DailyCausalityTests(unittest.TestCase):
    def setUp(self):
        self.x = market_frame("2020-01-01", "2021-01-01", varying=True)

    def test_completed_days_and_availability(self):
        d = one.daily_market(self.x.iloc[:-1])
        self.assertEqual(len(d), 365)
        self.assertTrue(d.bars.eq(6).all())
        self.assertEqual(d.time.iloc[0], pd.Timestamp("2020-01-02", tz="UTC"))
        self.assertEqual(d.signal_i.iloc[0], 5)

    def test_log_return_er_matches_monograph(self):
        d = one.daily_market(self.x)
        r = np.log(d.close / d.close.shift(1))
        expected = r.rolling(20).sum().abs() / (r.abs().rolling(20).sum()+1e-12)
        np.testing.assert_allclose(d.er20, expected, equal_nan=True)
        self.assertTrue(d.q.iloc[:20].isna().all())
        self.assertFalse(d.risk.iloc[:29].any())

    def test_per_feature_future_corruption_leaves_all_earlier_features_fixed(self):
        before = one.daily_market(self.x)
        cutoff = 6*120
        cols = one.H1A_MODELS["M2"] + ["time", "risk", "q", "atr", "funding3"]
        for col in ["open", "high", "low", "close", "volume", "funding_rate"]:
            bad = self.x.copy()
            bad.loc[cutoff:, col] = bad.loc[cutoff:, col]*7+1
            after = one.daily_market(bad)
            with self.subTest(col=col):
                assert_frame_equal(before.loc[:119, cols], after.loc[:119, cols])

    def test_warmup_is_not_a_neutral_episode(self):
        d = one.daily_market(self.x)
        first_valid = d.q.first_valid_index()
        self.assertEqual(first_valid, 20)
        self.assertEqual(d.neutral_days.iloc[first_valid-1], 0)
        self.assertFalse(d.risk.iloc[:first_valid+9].any())


class OnsetLabelTests(unittest.TestCase):
    @staticmethod
    def daily(q):
        q = np.asarray(q, float)
        age, n = [], 0
        for v in q:
            n = n+1 if v == 0 else 0
            age.append(n)
        return pd.DataFrame({"time": pd.date_range("2020-01-01", periods=len(q), freq="D", tz="UTC"),
                             "q": q, "risk": (q == 0) & (np.array(age) >= 10)})

    def test_first_crossing_confirmation_and_seven_day_label(self):
        q = np.zeros(100)
        q[30:41] = 1
        q[60] = -1
        q[95:] = 1
        d, e = one.onset_labels(self.daily(q))
        self.assertEqual(e.status.tolist(), ["CONFIRMED", "UNCONFIRMED", "CENSORED"])
        self.assertEqual(e.confirmation_time.iloc[0], d.time.iloc[40])
        self.assertTrue(d.y.iloc[23:30].eq(1).all())
        self.assertEqual(d.y.iloc[22], 0)
        self.assertEqual(d.y.iloc[59], 0)
        self.assertTrue(d.y.iloc[-17:].isna().all())
        self.assertTrue(pd.isna(d.y.iloc[30]))  # onset-day detection is NOT H1-A

    def test_requires_eight_of_next_ten_not_including_onset(self):
        q = np.zeros(70)
        q[30:38] = 1  # onset + seven subsequent: NOT enough
        _, e = one.onset_labels(self.daily(q))
        self.assertEqual(e.status.iloc[0], "UNCONFIRMED")
        q[40] = 1
        _, e = one.onset_labels(self.daily(q))
        self.assertEqual(e.status.iloc[0], "CONFIRMED")

    def test_future_labels_only_change_when_not_mature(self):
        q = np.zeros(100)
        q[50:61] = 1
        before, _ = one.onset_labels(self.daily(q))
        q[65:] = -1
        after, _ = one.onset_labels(self.daily(q))
        assert_frame_equal(before.loc[:47, ["y", "target_onset", "target_confirmation"]],
                           after.loc[:47, ["y", "target_onset", "target_confirmation"]])


class ForecastTests(unittest.TestCase):
    def test_scaler_does_not_fit_test_data(self):
        train = pd.DataFrame({"f": [-2., -1., 0., 1., 2., 3.], "y": [-1, 0, 1, -1, 0, 1]})
        test = pd.DataFrame({"f": [.5]})
        p = one.forecast_prob(train, test, ["f"], 1.)
        contaminated_test = pd.DataFrame({"f": [.5, 1e9]})
        np.testing.assert_allclose(p[0], one.forecast_prob(train, contaminated_test, ["f"], 1.)[0])
        np.testing.assert_allclose(p.sum(axis=1), 1)

    def test_missing_classes_use_logged_prior_fallback(self):
        train = pd.DataFrame({"f": [1., 2., 3.], "y": [0, 0, 1]})
        p = one.forecast_prob(train, train, ["f"], 1.)
        np.testing.assert_allclose(p[0], [3/6, 2/6, 1/6])
        self.assertTrue((p > 0).all())

    def test_brier_class_order_and_log_loss(self):
        bs, ll = one.forecast_losses([0, 1, -1], np.eye(3))
        np.testing.assert_allclose(bs, 0)
        np.testing.assert_allclose(ll, 0)

    def test_calendar_blocks_keep_gaps_and_paired_losses(self):
        frame = pd.DataFrame({"time": pd.to_datetime(["2020-01-01", "2020-01-30"], utc=True),
                              "M1": [.2, .8], "M2": [.2, .8]})
        result = one.block_interval(frame, ["M1", "M2"], ratio=True)
        self.assertEqual(result["estimate"], 0)
        self.assertEqual(result["ci95"], [0, 0])
        self.assertEqual([r["block_days"] for r in result["sensitivity"]], [28, 30, 30])
        self.assertEqual(result, one.block_interval(frame, ["M1", "M2"], ratio=True))

    def test_warning_utility_and_low_power_are_separate_gates(self):
        good_gain = {"estimate": .1, "ci95": [.01, .2]}
        silent = {"detected_events": 0, "false_per_asset_year": 0., "median_lead_days": None}
        self.assertEqual(one.h1a_gate(20, 20, 12, good_gain, silent)["verdict"], "REJECT_EARLY_WARNING_UTILITY")
        result = one.h1a_gate(2, 2, 3, good_gain, silent)
        self.assertIn("INCONCLUSIVE", result["verdict"])
        self.assertFalse(result["heldout_utility_gate"])
        good_alarm = {"detected_events": 2, "false_per_asset_year": 2., "median_lead_days": 3.}
        self.assertTrue(one.h1a_gate(20, 20, 12, good_gain, good_alarm)["heldout_utility_gate"])
        for alarms in ({**good_alarm, "false_per_asset_year": 3.01},
                       {**good_alarm, "median_lead_days": 1.},
                       {**good_alarm, "median_lead_days": None}):
            with self.subTest(alarms=alarms):
                result = one.h1a_gate(20, 20, 12, good_gain, alarms)
                self.assertEqual(result["verdict"], "REJECT_EARLY_WARNING_UTILITY")
                self.assertFalse(result["heldout_utility_gate"])
        boundary = {**good_alarm, "false_per_asset_year": 3., "median_lead_days": 2.}
        self.assertTrue(one.h1a_gate(20, 20, 12, good_gain, boundary)["heldout_utility_gate"])
        rows = pd.DataFrame({"time": pd.date_range("2023-01-01", periods=10, tz="UTC")})
        events = pd.DataFrame(columns=["status", "side", "onset_time", "onset_i"])
        disabled = one.alarm_metrics(rows, np.tile([0., 1., 0.], (10, 1)), 1.01, events, 1.)
        self.assertEqual(one.h1a_gate(20, 20, 12, good_gain, disabled)["verdict"],
                         "REJECT_EARLY_WARNING_UTILITY")

    def test_strict_pre_onset_matching_and_cooldown(self):
        rows = pd.DataFrame({"time": pd.date_range("2020-01-01", periods=15, freq="D", tz="UTC")})
        p = np.tile([.05, .9, .05], (15, 1))
        events = pd.DataFrame({"onset_i": [9], "onset_time": [rows.time.iloc[9]], "side": [1], "status": ["CONFIRMED"]})
        m = one.alarm_metrics(rows, p, .5, events, 1.)
        self.assertEqual(m["alarms"], 3)  # days 0,7,14
        self.assertEqual(m["detected_events"], 1)
        self.assertEqual(m["median_lead_days"], 2)
        self.assertEqual(m["false_alarms"], 2)
        at_onset = one.alarm_metrics(rows.iloc[9:], p[:6], .5, events, 1.)
        self.assertEqual(at_onset["detected_events"], 0)

    @staticmethod
    def synthetic_daily():
        rng = np.random.default_rng(42)
        time = pd.date_range("2020-01-01", "2023-08-20", freq="D", tz="UTC")
        n = len(time)
        d = pd.DataFrame({"time": time, "risk": np.arange(n) % 3 == 0,
                          "y": np.resize([0., 1., -1., 0., -1.], n),
                          "target_onset": pd.NaT, "target_confirmation": pd.NaT})
        for col in one.H1A_MODELS["M2"]:
            d[col] = rng.normal(size=n)
        d.loc[~d.risk | (d.time + pd.Timedelta(days=17) > time.max()), "y"] = np.nan
        events = pd.DataFrame(columns=["onset_i", "onset_time", "side", "status"])
        return d, events

    def test_archives_censored_predictions_but_scores_only_mature_rows(self):
        d, events = self.synthetic_daily()
        calls = []
        alarm_metrics = one.alarm_metrics

        def predict(train, test, cols, c):
            self.assertTrue(train.y.notna().all())
            return np.tile([.6, .25, .15], (len(test), 1))

        def alarms(rows, p, threshold, events, years):
            self.assertTrue(rows.y.notna().all())
            calls.append((rows.copy(), years))
            return alarm_metrics(rows, p, threshold, events, years)

        with patch.object(one, "forecast_prob", side_effect=predict), patch.object(
                one, "alarm_metrics", side_effect=alarms):
            forecasts, result = one.h1a_experiment(d, events)
        expected = d.loc[d.risk & d.time.ge(pd.Timestamp("2023-01-01", tz="UTC"))]
        self.assertEqual(forecasts.time.tolist(), expected.time.tolist())
        self.assertGreater(result["N_censored"], 0)
        self.assertEqual(result["N_forecasts"], len(expected))
        self.assertEqual(result["N_scored"], int(expected.y.notna().sum()))
        self.assertEqual(result["N_censored"], int(expected.y.isna().sum()))
        self.assertTrue(np.isfinite(forecasts.filter(regex="_(none|up|down)$")).all().all())
        scored = forecasts.loc[forecasts.y.notna()]
        bs, ll = one.forecast_losses(scored.y, scored[["M2_none", "M2_up", "M2_down"]].to_numpy())
        self.assertAlmostEqual(result["metrics"]["M2"]["brier"], bs.mean())
        self.assertAlmostEqual(result["metrics"]["M2"]["log_loss"], ll.mean())
        self.assertEqual(sum(b["N"] for b in result["metrics"]["M2"]["calibration_bins"]), len(scored))
        cap = d.time.max() - pd.Timedelta(days=16)
        expected_days = (cap-pd.Timestamp("2023-01-01", tz="UTC")).days
        self.assertEqual(result["exposure_days"], expected_days)
        self.assertEqual(result["exposure_ranges"][-1]["end_exclusive"], str(cap))
        self.assertTrue(all(years == expected_days/365.25 for _, years in calls[-3:]))
        for fold in result["folds"]:
            if fold.get("status") == "INSUFFICIENT_ROWS":
                continue
            start = pd.Timestamp(fold["start"])
            inner_end = start-pd.Timedelta(days=17)
            expected_inner = (inner_end-pd.Timestamp("2021-07-01", tz="UTC")).days
            self.assertEqual(fold["inner_exposure_days"], expected_inner)
            self.assertEqual(fold["inner_exposure"][-1]["end_exclusive"], str(inner_end))
            self.assertGreater(fold["inner_exposure_days"], fold["train_rows"] // 3)

    def test_all_censored_test_fold_still_archives_forecasts(self):
        d, events = self.synthetic_daily()
        d.loc[d.time.ge(pd.Timestamp("2023-01-01", tz="UTC")), "y"] = np.nan
        with patch.object(one, "forecast_prob", side_effect=lambda tr, te, cols, c:
                          np.tile([.6, .25, .15], (len(te), 1))):
            forecasts, result = one.h1a_experiment(d, events)
        self.assertGreater(len(forecasts), 0)
        self.assertTrue(forecasts.y.isna().all())
        self.assertEqual(result["N_scored"], 0)
        self.assertEqual(result["N_censored"], len(forecasts))
        self.assertIsNone(result["folds"][0]["models"]["M2"]["brier"])
        self.assertNotIn("metrics", result)

    def test_real_forecast_prefix_and_fitted_choices_ignore_future_mutation(self):
        d, events = self.synthetic_daily()
        cutoff = pd.Timestamp("2023-07-01", tz="UTC")
        changed = d.copy(deep=True)
        future = changed.time.ge(cutoff)
        changed.loc[future, one.H1A_MODELS["M2"]] = 1e6
        changed.loc[future & changed.y.notna(), "y"] = 1
        changed.loc[future, "risk"] = True
        first, result = one.h1a_experiment(d, events)
        second, mutated = one.h1a_experiment(changed, events)
        assert_frame_equal(first.loc[first.time.lt(cutoff)].reset_index(drop=True),
                           second.loc[second.time.lt(cutoff)].reset_index(drop=True))
        self.assertEqual(result["folds"][0], mutated["folds"][0])
        self.assertFalse(result["folds"][0]["prior_fallback"])
        self.assertTrue(all(m["inner_folds"] > 0 for m in result["folds"][0]["models"].values()))

    def test_nested_fits_purge_labels_and_ignore_post_fold_data(self):
        rng = np.random.default_rng(42)
        n = 1827
        d = pd.DataFrame({"time": pd.date_range("2020-01-01", periods=n, freq="D", tz="UTC"),
                          "risk": True, "y": np.resize([0, 0, 1, 0, -1], n),
                          "target_onset": pd.NaT, "target_confirmation": pd.NaT})
        for col in one.H1A_MODELS["M2"]:
            d[col] = rng.normal(size=n)
        e = pd.DataFrame({"onset_i": [1100], "onset_time": [d.time.iloc[1100]], "side": [1], "status": ["CONFIRMED"]})
        calls = []

        def fake(train, test, cols, c):
            self.assertLess(train.time.max()+pd.Timedelta(days=17), test.time.min())
            calls.append((train.time.max(), test.time.min()))
            return np.tile([.8, .1, .1], (len(test), 1))

        with patch.object(one, "forecast_prob", side_effect=fake):
            forecasts, result = one.h1a_experiment(d, e)
        self.assertGreater(len(calls), 30)
        self.assertEqual(len(result["folds"]), 4)
        self.assertTrue(forecasts.time.ge(pd.Timestamp("2023-01-01", tz="UTC")).all())
        self.assertFalse(result["minimum_evidence_met"])
        self.assertIn("INCONCLUSIVE", result["verdict"])


class ShortExecutionTests(unittest.TestCase):
    def frame(self):
        x = market_frame("2020-01-01", "2020-02-01").iloc[:50].copy()
        return x.assign(atr=2., high=100., low=100., funding_rate=0.)

    def test_short_entry_bar_tie_and_target(self):
        x = self.frame()
        x.loc[1, ["high", "low"]] = [104., 89.]
        r = one.evaluate_events(x, [0], side=-1)[0]
        self.assertEqual(r["exit"], "STOP")
        self.assertLess(r["net_R"], -1)
        x.loc[1, "high"] = 100.
        r = one.evaluate_events(x, [0], side=-1)[0]
        self.assertEqual(r["exit"], "TARGET")
        self.assertLess(r["net_R"], 3)
        self.assertGreater(r["net_R"], 2.8)

    def test_short_adverse_gap(self):
        x = self.frame()
        x.loc[2, ["open", "high", "low", "close"]] = [110., 111., 109., 110.]
        r = one.evaluate_events(x, [0], side=-1)[0]
        self.assertEqual(r["exit"], "STOP_GAP")
        self.assertAlmostEqual(r["exit_price"], 110*(1+one.SLIPPAGE_BPS/10000))

    def test_short_funding_sign_and_free_cost_identity(self):
        x = self.frame().assign(funding_rate=.001)
        r = one.evaluate_events(x, [0], barriers=False, side=-1, hold_bars=6)[0]
        self.assertEqual(r["funding_usdt_per_btc"], -.5)
        self.assertGreater(r["net_R"], r["net_R_ex_funding"])
        self.assertAlmostEqual(r["net_R"]+r["cost_R"], 0)
        self.assertEqual(r["exit_time"], str(x.time.iloc[6]))


class ResearchSafetyTests(TemporaryFiles):
    def test_empty_conditions_serialize_and_net_targets_are_not_gross_hits(self):
        frame = market_frame("2020-01-01", "2020-07-01", varying=True).assign(volume=1.)
        x = one.features(frame)
        obs, summaries = one.market_observations(x, one.daily_market(x))
        json.dumps(summaries, allow_nan=False)
        empty = next(s for s in summaries if s["condition"] == "high_volume")
        self.assertEqual(empty["N_overlapping_days"], 0)
        self.assertEqual(empty["status"], "INSUFFICIENT_DATA")
        self.assertIsNone(empty["horizons"]["1"]["mean_net"])
        self.assertEqual(empty["horizons"]["1"]["return_quantiles"], [None, None, None])
        self.assertIsNone(empty["barriers"]["3"]["net_R"])
        self.assertIsNone(empty["barriers"]["5"]["net_target_attainment"])
        self.assertEqual(empty["barriers"]["3"]["mean_ci"]["ci95"], [None, None])
        all_momentum = summaries[0]
        self.assertIn("net_target_attainment", all_momentum["barriers"]["3"])
        self.assertIn("gross_barrier_hit", all_momentum["barriers"]["3"])
        self.assertTrue(obs["net_R_3"].notna().all())
        aligned = obs.loc[obs.momentum_aligned]
        for target in (3, 5):
            barrier = all_momentum["barriers"][str(target)]
            self.assertEqual(barrier["exit_policy"], f"gross_{target}R_target_or_1R_stop_or_7d_timeout")
            self.assertEqual(barrier["gross_barrier_hit"], aligned[f"gross_barrier_hit_{target}"].mean())
            self.assertEqual(barrier["net_target_attainment"], aligned[f"net_R_{target}"].ge(target).mean())
            self.assertEqual(barrier["stress_net_target_attainment"], aligned[f"stress_R_{target}"].ge(target).mean())

    def test_gross_target_hits_below_net_threshold_are_not_attainments(self):
        frame = market_frame("2020-01-01", "2020-07-01", varying=True).assign(volume=1.)
        x = one.features(frame)
        evaluate = one.evaluate_events

        def gross_hits(*args, **kwargs):
            rows = evaluate(*args, **kwargs)
            if kwargs.get("barriers", True):
                target = kwargs["target_r"]
                for row in rows:
                    row.update(target_before_stop=1., net_R=target-.03, exit="TARGET")
            return rows

        with patch.object(one, "evaluate_events", side_effect=gross_hits):
            _, summaries = one.market_observations(x, one.daily_market(x))
        json.dumps(summaries, allow_nan=False)
        for target in (3, 5):
            barrier = summaries[0]["barriers"][str(target)]
            self.assertEqual(barrier["gross_barrier_hit"], 1.)
            self.assertEqual(barrier["net_target_attainment"], 0.)
            self.assertEqual(barrier["stress_net_target_attainment"], 0.)

    def test_research_cannot_unlock_oos_even_with_download(self):
        with patch.object(one, "download") as download:
            code, _, text = self.run_cli(["--research", "--unlock-oos", "--download"])
        self.assertEqual(code, 2)
        self.assertIn("frozen DEV only", text)
        download.assert_not_called()

    def test_all_research_output_paths_are_distinct(self):
        code, _, text = self.run_cli(["--research", "--forecasts", str(self.csv)])
        self.assertEqual(code, 2)
        self.assertIn("distinct", text)

    def test_protocol_written_before_labels_and_mismatch_fails_closed(self):
        args = argparse.Namespace(protocol=str(self.root/"protocol.json"))
        readiness = {"file_sha256": "data", "code_sha256": "code"}
        with (patch.object(one, "daily_market", side_effect=RuntimeError("before any labels")),
              self.assertRaisesRegex(RuntimeError, "before any labels")):
            one.research_run(pd.DataFrame(), readiness, args)
        frozen = json.loads(Path(args.protocol).read_text())
        self.assertEqual(frozen["identity"]["input_sha256"], "data")
        with patch.object(one, "daily_market") as aggregate:
            with self.assertRaisesRegex(ValueError, "mismatch"):
                one.research_run(pd.DataFrame(), {**readiness, "code_sha256": "changed"}, args)
            aggregate.assert_not_called()


if __name__ == "__main__":
    unittest.main()
