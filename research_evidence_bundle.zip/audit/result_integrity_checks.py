"""Post-run integrity/descriptive audit only; no refits, variants, downloads or OOS."""
import hashlib
import json
from pathlib import Path
import numpy as np
import pandas as pd
import sys
sys.path.insert(0, str(Path.cwd()))
import one

p = json.loads(Path('research_protocol.json').read_text())
e = json.loads(Path('research_evidence.json').read_text())
assert hashlib.sha256(Path('one.py').read_bytes()).hexdigest() == p['identity']['code_sha256']
for name, digest in e['outputs'].items():
    assert hashlib.sha256(Path(name).read_bytes()).hexdigest() == digest, name
f = pd.read_csv('h1a_forecasts.csv')
for col in ['time', 'target_onset', 'target_confirmation', 'label_maturity_time']:
    f[col] = pd.to_datetime(f[col], utc=True)
assert len(f) == e['h1a']['N_forecasts'] == 346
assert int(f.y.isna().sum()) == e['h1a']['N_censored'] == 6
all_forecasts = f.copy()
f = f.loc[f.y.notna()].copy()
assert len(f) == e['h1a']['N_scored'] == 340
for model in ['M0','M1','M2','placebo']:
    probs=f[[f'{model}_{s}' for s in ['none','up','down']]].to_numpy()
    assert np.allclose(probs.sum(axis=1), 1)
    assert (probs >= 0).all()
    bs,ll=one.forecast_losses(f.y,probs)
    assert np.isclose(bs.mean(), e['h1a']['metrics'][model]['brier'])
    assert np.isclose(ll.mean(), e['h1a']['metrics'][model]['log_loss'])
pos=f.y.ne(0)
leads=(f.loc[pos,'target_onset']-f.loc[pos,'time']).dt.days
assert leads.between(1,7).all()
assert (f.loc[pos,'target_confirmation']-f.loc[pos,'target_onset']).dt.days.eq(10).all()
assert f.label_maturity_time.le(pd.Timestamp(one.DEV_END,tz='UTC')).all()
raw=pd.read_csv('btc_4h.csv', float_precision='round_trip')
x=one.validate(raw)
assert x.time.max() < pd.Timestamp(one.DEV_END,tz='UTC')
d=one.daily_market(x)
events=pd.read_csv('h1a_onsets.csv')
confirmed=events[events.status.eq('CONFIRMED')]
o=pd.read_csv('market_observations.csv')
aligned=o[o.momentum_aligned]
risk_percent=1.5*aligned.atr/aligned.close*100
runs=[]
for _,g in d[d.q.notna()].groupby(d.q.ne(d.q.shift()).cumsum()):
    runs.append({'q':int(g.q.iloc[0]),'days':len(g),'censored_right':bool(g.index[-1]==d.index[-1])})
r=pd.DataFrame(runs)
result={
 'integrity_checks':'PASS; hashes, probabilities, Brier/logloss, lead, confirmation, maturity and DEV bounds',
 'positive_forecast_rows':int(pos.sum()),
 'forecast_counts':{'all_eligible':len(all_forecasts),'scored_mature':len(f),'censored_unscored':int(all_forecasts.y.isna().sum())},
 'final_source_sha256':hashlib.sha256(Path('one.py').read_bytes()).hexdigest(),
 'source_snapshot_sha256':hashlib.sha256(Path('research_source_snapshot.zip').read_bytes()).hexdigest(),
 'confirmed_onsets_full_dev_by_side':{str(k):int(v) for k,v in confirmed.side.value_counts().items()},
 'risk_percent_dailyATR_1R_quantiles':risk_percent.quantile([.1,.5,.9]).to_dict(),
 'q_run_lengths_POSTHOC_DESCRIPTIVE':{str(q):{'episodes':len(g),'median_days':float(g.days.median()),'max_days':int(g.days.max())} for q,g in r[~r.censored_right].groupby('q')},
 'contemporaneous_volume_absreturn_spearman_POSTHOC':float(d.volume_surprise.corr(d.r1.abs(),method='spearman')),
 'daily_return_lag1_correlation_POSTHOC':float(d.r1.autocorr()),
 'daily_absreturn_lag1_correlation_POSTHOC':float(d.r1.abs().autocorr()),
 'all_entries_by_side_POSTHOC_DESCRIPTIVE':{str(side):{'N':len(g),'net_R_3':float(g.net_R_3.mean()),'net_R_5':float(g.net_R_5.mean())} for side,g in o.groupby('side')},
 'aligned_entries_by_side_POSTHOC_DESCRIPTIVE':{str(side):{'N':len(g),'net_R_3':float(g.net_R_3.mean()),'net_R_5':float(g.net_R_5.mean())} for side,g in aligned.groupby('side')},
}
Path('research_integrity_audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps(result,indent=2))
